import Link from "next/link";

const cases = [
  { id: 1, name: "Danger Zone", price: 149, category: "popular" },
  { id: 2, name: "Dreams & Nightmares", price: 249, category: "popular" },
  { id: 3, name: "Kilowatt", price: 99, category: "cheap" },
  { id: 4, name: "Revolution", price: 199, category: "popular" },
  { id: 5, name: "Gallery", price: 79, category: "cheap" },
  { id: 6, name: "Recoil", price: 179, category: "popular" },
  { id: 7, name: "Snakebite", price: 129, category: "popular" },
  { id: 8, name: "Fracture", price: 89, category: "cheap" },
];

export default function CasesPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-3">Кейсы</h1>
        <p className="text-text-secondary">Выбери кейс и испытай удачу. Все скины — настоящие CS2.</p>
      </div>

      <div className="flex flex-wrap gap-2 mb-8">
        {["Все", "Популярные", "Дешёвые", "Новые"].map((f, i) => (
          <button
            key={f}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              i === 0
                ? "bg-primary text-white"
                : "bg-background-card border border-border text-text-secondary hover:text-white hover:border-primary/50"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
        {cases.map((c) => (
          <Link
            key={c.id}
            href={`/cases/${c.id}`}
            className="card overflow-hidden group hover:border-primary/50 transition-all hover:shadow-glow"
          >
            <div className="aspect-square bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center">
              <div className="w-20 h-20 md:w-28 md:h-28 rounded-xl bg-background-card/60 border border-white/10 flex items-center justify-center text-3xl group-hover:scale-105 transition-transform">
                📦
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-sm md:text-base truncate mb-1">{c.name}</h3>
              <div className="flex items-center justify-between">
                <span className="text-primary font-bold">{c.price} ₽</span>
                <span className="text-xs text-text-muted uppercase">
                  {c.category === "cheap" ? "Дешёвый" : "Популярный"}
                </span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
