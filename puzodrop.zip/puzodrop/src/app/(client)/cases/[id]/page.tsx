"use client";

import { useState } from "react";
import Link from "next/link";
import Button from "@/components/ui/Button";

const caseData = {
  id: 1,
  name: "Danger Zone",
  price: 149,
  description: "Классический кейс с оружием из операции Danger Zone.",
  items: [
    { name: "AWP | Neo-Noir", rarity: "Covert", chance: 0.26, price: 4500 },
    { name: "AK-47 | Asiimov", rarity: "Covert", chance: 0.64, price: 2800 },
    { name: "M4A4 | Neo-Noir", rarity: "Classified", chance: 3.2, price: 450 },
    { name: "USP-S | Cortex", rarity: "Classified", chance: 3.2, price: 380 },
    { name: "Glock-18 | Oxide Blaze", rarity: "Restricted", chance: 15.98, price: 45 },
    { name: "MP9 | Modest Threat", rarity: "Mil-Spec", chance: 76.72, price: 8 },
  ],
};

const rarityColors: Record<string, string> = {
  Covert: "text-red-400 border-red-500/40 bg-red-500/10",
  Classified: "text-pink-400 border-pink-500/40 bg-pink-500/10",
  Restricted: "text-purple-400 border-purple-500/40 bg-purple-500/10",
  "Mil-Spec": "text-blue-400 border-blue-500/40 bg-blue-500/10",
};

export default function CaseOpenPage() {
  const [isOpening, setIsOpening] = useState(false);
  const [openedItem, setOpenedItem] = useState<typeof caseData.items[0] | null>(null);

  const handleOpen = () => {
    setIsOpening(true);
    setOpenedItem(null);
    setTimeout(() => {
      const rand = Math.random() * 100;
      let cumulative = 0;
      let selected = caseData.items[caseData.items.length - 1];
      for (const item of caseData.items) {
        cumulative += item.chance;
        if (rand <= cumulative) {
          selected = item;
          break;
        }
      }
      setOpenedItem(selected);
      setIsOpening(false);
    }, 2500);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10">
      <Link href="/cases" className="inline-flex items-center gap-2 text-text-secondary hover:text-white mb-8 transition">
        ← Назад к кейсам
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div>
          <div className="card p-8 flex flex-col items-center">
            <div className="w-48 h-48 md:w-64 md:h-64 rounded-2xl bg-gradient-to-br from-primary/30 to-accent/20 flex items-center justify-center mb-6 relative overflow-hidden">
              {isOpening ? (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-32 h-32 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              ) : openedItem ? (
                <div className="text-center p-4">
                  <p className="text-sm text-text-muted mb-1">Выпало:</p>
                  <p className="font-bold text-lg">{openedItem.name}</p>
                  <p className="text-primary font-semibold mt-1">{openedItem.price} ₽</p>
                </div>
              ) : (
                <span className="text-6xl">📦</span>
              )}
            </div>

            <h1 className="text-2xl font-bold mb-2">{caseData.name}</h1>
            <p className="text-text-secondary text-sm mb-6 text-center">{caseData.description}</p>
            <div className="flex items-center gap-4 mb-6">
              <span className="text-3xl font-bold text-primary">{caseData.price} ₽</span>
            </div>

            <Button size="lg" className="w-full max-w-xs" onClick={handleOpen} isLoading={isOpening} disabled={isOpening}>
              {openedItem ? "Открыть ещё" : "Открыть кейс"}
            </Button>
          </div>
        </div>

        <div>
          <h2 className="font-semibold text-lg mb-4">Содержимое кейса</h2>
          <div className="space-y-2">
            {caseData.items.map((item) => (
              <div key={item.name} className="card p-3 flex items-center justify-between gap-3 hover:border-border-light transition">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-lg bg-background-secondary flex items-center justify-center shrink-0 text-lg">🔫</div>
                  <div className="min-w-0">
                    <p className="font-medium text-sm truncate">{item.name}</p>
                    <span className={`badge border text-xs ${rarityColors[item.rarity] || ""}`}>{item.rarity}</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-semibold">{item.price} ₽</p>
                  <p className="text-xs text-text-muted">{item.chance}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
