import Link from "next/link";
import Button from "@/components/ui/Button";

const featuredCases = [
  { id: 1, name: "Danger Zone", price: 149, color: "from-red-600/40 to-orange-500/20" },
  { id: 2, name: "Dreams & Nightmares", price: 249, color: "from-purple-600/40 to-pink-500/20" },
  { id: 3, name: "Kilowatt", price: 99, color: "from-yellow-500/40 to-amber-600/20" },
  { id: 4, name: "Revolution", price: 199, color: "from-blue-600/40 to-cyan-500/20" },
];

export default function HomePage() {
  return (
    <div>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-glow pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-20 md:py-28 text-center relative">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-6">
            Открывай кейсы{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              CS2
            </span>
          </h1>
          <p className="text-lg md:text-xl text-text-secondary max-w-2xl mx-auto mb-10">
            Лучшие кейсы, честные шансы, быстрый вывод скинов на Steam.
            Апгрейды, инвентарь и реферальная система.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/cases">
              <Button size="lg" className="w-full sm:w-auto">Открыть кейсы</Button>
            </Link>
            <Link href="/upgrade">
              <Button variant="outline" size="lg" className="w-full sm:w-auto">Апгрейд</Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { title: "Кейсы CS2", desc: "Оригинальные скины из Counter-Strike 2. Реальные шансы." },
            { title: "Апгрейды", desc: "Улучшай свои скины и получай более дорогие предметы." },
            { title: "Быстрый вывод", desc: "Выводи скины прямо на свой Steam-аккаунт." },
          ].map((f) => (
            <div key={f.title} className="card p-6 hover:border-primary/40 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center mb-4 text-primary font-bold text-xl">
                {f.title[0]}
              </div>
              <h3 className="font-semibold text-lg mb-2">{f.title}</h3>
              <p className="text-text-secondary text-sm">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl md:text-3xl font-bold">Популярные кейсы</h2>
          <Link href="/cases" className="text-primary hover:text-primary-light text-sm font-medium">
            Все кейсы →
          </Link>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {featuredCases.map((c) => (
            <Link
              key={c.id}
              href={`/cases/${c.id}`}
              className="card overflow-hidden group hover:border-primary/50 transition-all hover:shadow-glow"
            >
              <div className={`aspect-square bg-gradient-to-br ${c.color} flex items-center justify-center relative`}>
                <div className="w-24 h-24 md:w-32 md:h-32 rounded-xl bg-background-card/50 border border-white/10 flex items-center justify-center text-4xl">
                  📦
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-sm md:text-base truncate mb-1">{c.name}</h3>
                <p className="text-primary font-bold">{c.price} ₽</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="card p-8 md:p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-accent/10 pointer-events-none" />
          <h2 className="text-2xl md:text-3xl font-bold mb-4 relative">Готов начать?</h2>
          <p className="text-text-secondary mb-8 max-w-lg mx-auto relative">
            Зарегистрируйся, пополни баланс и открывай кейсы уже сейчас.
          </p>
          <div className="relative">
            <Button size="lg">Создать аккаунт</Button>
          </div>
        </div>
      </section>
    </div>
  );
}
