"use client";

import Button from "@/components/ui/Button";

export default function AdminSettingsPage() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1">Настройки</h1>
        <p className="text-text-secondary text-sm">
          Основные настройки сайта и платежей
        </p>
      </div>

      <div className="space-y-6 max-w-2xl">
        {/* Site settings */}
        <div className="card p-6">
          <h2 className="font-semibold mb-4">Сайт</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-text-secondary mb-1.5 block">
                Название сайта
              </label>
              <input
                type="text"
                defaultValue="PuzoDrop"
                className="input-field"
              />
            </div>
            <div>
              <label className="text-sm text-text-secondary mb-1.5 block">
                Минимальный депозит (₽)
              </label>
              <input
                type="number"
                defaultValue={50}
                className="input-field"
              />
            </div>
            <div>
              <label className="text-sm text-text-secondary mb-1.5 block">
                Минимальный вывод (₽)
              </label>
              <input
                type="number"
                defaultValue={100}
                className="input-field"
              />
            </div>
          </div>
        </div>

        {/* Payments */}
        <div className="card p-6">
          <h2 className="font-semibold mb-4">Платежи (карты)</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-text-secondary mb-1.5 block">
                Платёжный провайдер
              </label>
              <select className="input-field">
                <option>CloudPayments</option>
                <option>ЮKassa</option>
                <option>Stripe</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-text-secondary mb-1.5 block">
                Public Key / Shop ID
              </label>
              <input
                type="text"
                placeholder="Введите ключ"
                className="input-field"
              />
            </div>
            <div>
              <label className="text-sm text-text-secondary mb-1.5 block">
                Secret Key
              </label>
              <input
                type="password"
                placeholder="••••••••"
                className="input-field"
              />
            </div>
          </div>
        </div>

        {/* Referral */}
        <div className="card p-6">
          <h2 className="font-semibold mb-4">Реферальная система</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-text-secondary mb-1.5 block">
                Процент рефералу (%)
              </label>
              <input
                type="number"
                defaultValue={5}
                className="input-field"
              />
            </div>
          </div>
        </div>

        <Button>Сохранить настройки</Button>
      </div>
    </div>
  );
}
