"use client";

import Button from "@/components/ui/Button";

const mockSkins = [
  { id: 1, name: "AWP | Neo-Noir", rarity: "Covert", price: 4500, steamId: "12345" },
  { id: 2, name: "AK-47 | Asiimov", rarity: "Covert", price: 2800, steamId: "12346" },
  { id: 3, name: "M4A4 | Neo-Noir", rarity: "Classified", price: 450, steamId: "12347" },
];

const rarityColors: Record<string, string> = {
  Covert: "text-red-400",
  Classified: "text-pink-400",
  Restricted: "text-purple-400",
  "Mil-Spec": "text-blue-400",
};

export default function AdminSkinsPage() {
  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-1">Скины</h1>
          <p className="text-text-secondary text-sm">Каталог всех предметов CS2</p>
        </div>
        <Button size="sm">+ Добавить скин</Button>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-text-muted">
                <th className="px-5 py-3 font-medium">Скин</th>
                <th className="px-5 py-3 font-medium">Редкость</th>
                <th className="px-5 py-3 font-medium">Цена</th>
                <th className="px-5 py-3 font-medium">Steam ID</th>
                <th className="px-5 py-3 font-medium text-right">Действия</th>
              </tr>
            </thead>
            <tbody>
              {mockSkins.map((s) => (
                <tr key={s.id} className="border-b border-border last:border-0 hover:bg-background-hover/50 transition">
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-background-secondary flex items-center justify-center text-lg">🔫</div>
                      <span className="font-medium">{s.name}</span>
                    </div>
                  </td>
                  <td className="px-5 py-4"><span className={rarityColors[s.rarity] || ""}>{s.rarity}</span></td>
                  <td className="px-5 py-4 font-semibold">{s.price} ₽</td>
                  <td className="px-5 py-4 text-text-muted font-mono text-xs">{s.steamId}</td>
                  <td className="px-5 py-4">
                    <div className="flex items-center justify-end gap-2 text-text-secondary">
                      <button className="hover:text-white transition text-sm">Изменить</button>
                      <button className="hover:text-accent transition text-sm">Удалить</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
