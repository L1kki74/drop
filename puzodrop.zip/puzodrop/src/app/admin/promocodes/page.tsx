"use client";
import Button from "@/components/ui/Button";

export default function AdminPromocodesPage() {
  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-1">Промокоды</h1>
          <p className="text-text-secondary text-sm">Создание и управление промокодами</p>
        </div>
        <Button size="sm">+ Создать промокод</Button>
      </div>
      <div className="card p-16 text-center text-text-muted">Промокодов пока нет</div>
    </div>
  );
}
