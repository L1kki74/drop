"use client";

import { useState } from "react";
import Button from "@/components/ui/Button";

const mockCases = [
  { id: 1, name: "Danger Zone", price: 149, itemsCount: 12, isActive: true, opens: 0 },
  { id: 2, name: "Dreams & Nightmares", price: 249, itemsCount: 15, isActive: true, opens: 0 },
  { id: 3, name: "Kilowatt", price: 99, itemsCount: 10, isActive: false, opens: 0 },
];

export default function AdminCasesPage() {
  const [cases] = useState(mockCases);

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-1">Кейсы</h1>
          <p className="text-text-secondary text-sm">Управление кейсами и их содержимым</p>
        </div>
        <Button size="sm">+ Добавить кейс</Button>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-text-muted">
                <th className="px-5 py-3 font-medium">Кейс</th>
                <th className="px-5 py-3 font-medium">Цена</th>
                <th className="px-5 py-3 font-medium">Предметов</th>
                <th className="px-5 py-3 font-medium">Открытий</th>
                <th className="px-5 py-3 font-medium">Статус</th>
                <th className="px-5 py-3 font-medium text-right">Действия</th>
              </tr>
            </thead>
            <tbody>
              {cases.map((c) => (
                <tr key={c.id} className="border-b border-border last:border-0 hover:bg-background-hover/50 transition">
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center text-lg">📦</div>
                      <span className="font-medium">{c.name}</span>
                    </div>
                  </td>
                  <td className="px-5 py-4 font-semibold text-primary">{c.price} ₽</td>
                  <td className="px-5 py-4 text-text-secondary">{c.itemsCount}</td>
                  <td className="px-5 py-4 text-text-secondary">{c.opens}</td>
                  <td className="px-5 py-4">
                    <span className={`badge ${c.isActive ? "bg-success/15 text-success" : "bg-text-muted/15 text-text-muted"}`}>
                      {c.isActive ? "Активен" : "Скрыт"}
                    </span>
                  </td>
                  <td className="px-5 py-4">
                    <div className="flex items-center justify-end gap-2 text-text-secondary">
                      <button className="hover:text-white transition text-sm">Изменить</button>
                      <button className="hover:text-accent transition text-sm">Удалить</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
